package com.group.mamacare.model;

public enum Gender {

	Male, Female, Others
}
