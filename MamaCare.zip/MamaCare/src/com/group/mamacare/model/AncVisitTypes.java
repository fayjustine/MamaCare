package com.group.mamacare.model;

public enum AncVisitTypes {
	VisitOne, VisitTwo, VisitThree, VisitFour, Other
}
