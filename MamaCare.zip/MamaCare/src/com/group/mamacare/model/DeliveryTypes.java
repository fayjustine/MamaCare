package com.group.mamacare.model;

public enum DeliveryTypes {

	None, Normal, Ceserian, Others
}
