package com.group.viewholders;

import android.content.Context;


public class BaseViewHolder {

	public Context cont;

	public BaseViewHolder(Context context) {
		cont = context;
	}
}
