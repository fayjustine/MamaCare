/** Automatically generated file. DO NOT MODIFY */
package com.group.mamacare;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}